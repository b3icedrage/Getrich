package com.pockettrader.app.signals

import com.pockettrader.app.protocol.Candle
import com.pockettrader.app.protocol.Direction

data class Signal(
    val id: Long,
    val asset: String,
    val direction: Direction,
    val strategy: StrategyType,
    val reason: String,
    /** Close time of the candle that produced the signal = entry time (unix sec, server clock). */
    val entryAtSec: Long,
    val expirySec: Int,
    /** Wall-clock millis when the app emitted the signal. */
    val emittedAtMs: Long,
)

/**
 * Feeds ticks into a signal-timeframe aggregator and a higher-timeframe aggregator and
 * evaluates the selected strategy exactly once per closed signal candle.
 */
class SignalEngine(cfg: StrategyConfig) {
    var config: StrategyConfig = cfg
        private set
    var ltf = CandleAggregator(cfg.timeframeSec)
        private set
    var htf = CandleAggregator(cfg.higherTimeframeSec)
        private set
    private var lastEvaluated = Long.MIN_VALUE
    private var nextId = 1L

    fun reconfigure(cfg: StrategyConfig) {
        val tfChanged = cfg.timeframeSec != config.timeframeSec || cfg.higherTimeframeSec != config.higherTimeframeSec
        config = cfg
        if (tfChanged) {
            ltf = CandleAggregator(cfg.timeframeSec); htf = CandleAggregator(cfg.higherTimeframeSec)
            lastEvaluated = Long.MIN_VALUE
        }
    }

    fun reset() { ltf.reset(); htf.reset(); lastEvaluated = Long.MIN_VALUE }

    /** Returns a signal when this tick closed a signal candle and the strategy fired. */
    fun onTick(asset: String, tsSec: Double, price: Double, nowMs: Long): Signal? {
        htf.onTick(tsSec, price)
        val closed = ltf.onTick(tsSec, price) ?: return null
        return evaluate(asset, closed, nowMs)
    }

    /** Clock-driven close so the signal is emitted at the boundary even with no new tick. */
    fun onClock(asset: String, serverNowSec: Double, nowMs: Long): Signal? {
        htf.onClock(serverNowSec)
        val closed = ltf.onClock(serverNowSec) ?: return null
        return evaluate(asset, closed, nowMs)
    }

    private fun evaluate(asset: String, closed: Candle, nowMs: Long): Signal? {
        if (closed.startSec <= lastEvaluated) return null
        lastEvaluated = closed.startSec
        val htfCandles = htf.candles + listOfNotNull(htf.forming)
        val d = Strategies.evaluate(config, ltf.candles, htfCandles) ?: return null
        return Signal(nextId++, asset, d.direction, d.strategy, d.reason,
            closed.startSec + config.timeframeSec, config.expirySec, nowMs)
    }
}
